<?php

namespace Drupal\drupal_training\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormBase;


class AutoSearchSiva extends FormBase {
   
   public function getFormId() {
	
	return 'siva_auto_search_form';
	
  }
    /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
		
		$form['question'] = array(
		  '#type' => 'textfield',
		  '#title' => t('Question'),
		  '#autocomplete_route_name' => 'hello.autocontroller',
          //'#autocomplete_route_parameters' => [],
		  //'#value' => $config->get('training_about'),
		  '#required' => TRUE,
		);
		$form['submit'] = array(
		  '#type' => 'submit',
		  '#value' => t('Submit'),
		);
		return $form;
	  
  
  }
  
   /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  
	
	
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
	
  }

}