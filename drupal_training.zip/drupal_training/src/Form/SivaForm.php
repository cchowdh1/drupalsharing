<?php

namespace Drupal\drupal_training\Form;

use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Form\FormBase;


class SivaForm extends FormBase {
   
   public function getFormId() {
	
	return 'siva_form';
	
  }
    /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config('common.settings');
		
		$form['question'] = array(
		  '#type' => 'textfield',
		  '#title' => t('Question'),
		  //'#value' => $config->get('training_about'),
		  '#required' => TRUE,
		);
		$form['answer'] = array(
		  '#type' => 'textfield',
		  '#title' => t('Answer'),
		  //'#value' => $config->get('training_about'),
		  '#required' => TRUE,
		);		
		$form['submit'] = array(
		  '#type' => 'submit',
		  '#value' => t('Submit'),
		);
		return $form;
	  
  
  }
  
   /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
  
	//echo "<pre>"; print_r($form_state->getUserInput());exit;
	$form_value = $form_state->getUserInput();
	if(is_numeric($form_value['question'])) {
	 $form_state->setErrorByName('question','Please enter a valid question');
	}
	
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
	$form_value = $form_state->getUserInput();
    $connection = \Drupal::database();
	$result = $connection->insert('qa')
     ->fields([
    'question' => $form_value['question'],
    'answer' => $form_value['answer'],
  ])
  ->execute();
	
  }

}