<?php

namespace Drupal\drupal_training\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Configure user settings for this site.
 *
 * @internal
 */
class CommonSettings extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'common_settings';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'common.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    // $form = parent::buildForm($form, $form_state);.
    $config = $this->config('common.settings');

    // Done for User Registration Form.
  
    $form['training_about'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Trainng Title'),
      '#default_value' => $config->get('training_about'),
     // '#description' => $this->t('This is for the front page timer title (just above the timer) in English'),
      '#required' => TRUE,
    ];
    
    // Done for User Registration Form.
    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('common.settings')
      ->set('training_about', $form_state->getValue('training_about'))
      ->save();
    parent::submitForm($form, $form_state);
  }

}