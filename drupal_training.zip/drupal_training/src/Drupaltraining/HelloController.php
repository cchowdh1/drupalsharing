<?php
/**
 * @file
 * Contains \Drupal\drupal_training\Drupaltraining\HelloController.
 */
namespace Drupal\drupal_training\Drupaltraining;
class HelloController {
  public function content() {
    return array(
      '#type' => 'markup',
      '#markup' => t('Hello, World!'),
    );
  }
  public function content_siva() {
    return array(
      '#type' => 'markup',
      '#markup' => t('Hi, Siva!'),
    );
  }
}