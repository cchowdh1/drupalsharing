<?php

namespace Drupal\drupal_training\Drupaltraining;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


/**
 * Defines a route controller for entity autocomplete form elements.
 */
class AutoSearchQues extends ControllerBase {

  /**
   * Handler for autocomplete request to select Program.
   */
  public function sivaAutocomplete(Request $request) {
    $connection = \Drupal::database();
    $auto_query = $connection->select('qa', 'qa')
      ->fields('qa', ['question']);
    $auto_query->condition('qa.question', $connection->escapeLike($request->query->get('q')) . '%', 'LIKE');
    $output_query = $auto_query->execute();
    while ($final_data = $output_query->fetchObject()) {
       $results[] = [
        'value' => $final_data->question,
        'label' => $final_data->question,
      ];
    }
    return new JsonResponse($results);
  }
}